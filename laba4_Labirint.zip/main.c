

#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <Windows.h>

#define BUFFER_SIZE	2001

char labirint[BUFFER_SIZE][BUFFER_SIZE];
int labirint_values[BUFFER_SIZE][BUFFER_SIZE];
char output[BUFFER_SIZE][BUFFER_SIZE];

const char const UP_VALUES[9] = "02468ACE";
const char const DOWN_VALUES[9] = "012389AB";
const char const RIGHT_VALUES[9] = "014589CD";
const char const LEFT_VALUES[9] = "01234567";

typedef struct coords {
	int x;
	int y;
} COORDS;


int isContainIn(char c, const char const buff[])
{
	int i = 0;
	int len = strlen(buff);
	for (; i < len; i++)
	{
		if (buff[i] == c)
			return 1;
	}
	return 0;
}

int canUp(char c)
{
	return isContainIn(c, UP_VALUES);
}

int canDown(char c)
{
	return isContainIn(c, DOWN_VALUES);
}

int canRight(char c)
{
	return isContainIn(c, RIGHT_VALUES);
}

int canLeft(char c)
{
	return isContainIn(c, LEFT_VALUES);
}


int processCell(int x, int y, int h, int w, COORDS* crds, int startIndex);
void drawLabirint(int h, int w, int onlySaveInFile);
void printCell(char ch, int x, int y, int onlySaveInFile);
COORDS** searchPath(int h, int w, int* lenPath, int fromX, int fromY, int toX, int toY);
void createPathByWeight(int h, int w, int* lenPath, COORDS** res);
void drawPath(COORDS** lcrs, int len);

int main()
{
	char path[201];
	path[200] = 0;
	printf("Enter the file path:  ");
	scanf("%200s", &path);
	OemToCharA(&path, &path);

	FILE* file = fopen(path, "r");
	FILE* outFile = fopen("output.txt", "w");

	int height, width;

	if (file != NULL && outFile != NULL && fscanf(file, "%d %d\n", &height, &width) == 2)
	{
		int x, y;
		char line[BUFFER_SIZE];

		for (x = 0; x < height; x++)
		{
			fgets(line, BUFFER_SIZE, file);

			for (y = 0; y < width; y++)
			{
				labirint[x][y] = line[y];
				labirint_values[x][y] = 0;
			}
		}

		for (x = 0; x < height + 4; x++)
		{
			memset(output[x], ' ', width);
		}

		drawLabirint(height, width, width > 500);

		int lenPath = 0;
		labirint_values[0][0] = 1;
		COORDS** fastestPath = searchPath(height, width, &lenPath, 0, 0, height - 1, width - 1);
		drawPath(fastestPath, lenPath);


		printf("\033[%d;%dH", height * 4, 0);
		printf("MIN:  [ %d ]\n", lenPath);

		rewind(outFile);
		fprintf(outFile, "MIN:  [ %d ]\n", lenPath);


		for (x = 0; x < lenPath; x++)
			free(fastestPath[x]);
		free(fastestPath);

		for (x = 0; x < height * 3 + 2; x++)
		{
			fprintf(outFile, "%s\n", output[x]);
		}
	}
	else
	{
		printf("Error to get height and width.");
	}

	fclose(file);
	fclose(outFile);

	return 0;
}

COORDS** searchPath(int h, int w, int* lenPath, int fromX, int fromY, int toX, int toY)
{
	int x = 0;
	int y = 0;
	int countCellsToProcess = 1;
	int curIndexToWrite = 1;
	int curIndexToRead = 0;
	int lastIndexToRead = BUFFER_SIZE;
	COORDS queueCells[BUFFER_SIZE];
	queueCells[0].x = fromX;
	queueCells[0].y = fromY;

	while (countCellsToProcess != 0)
	{
		if (curIndexToRead == lastIndexToRead + 1)
			curIndexToRead = 0;

		x = queueCells[curIndexToRead].x;
		y = queueCells[curIndexToRead].y;

		if (x == toX && y == toY)
		{
			*lenPath = labirint_values[x][y];
			break;
		}


		if (curIndexToWrite > BUFFER_SIZE - 5)
		{
			lastIndexToRead = curIndexToWrite - 1;
			curIndexToWrite = 0;
		}

		int countNewCells = processCell(x, y, h, w, &queueCells, curIndexToWrite);
		curIndexToWrite += countNewCells;

		countCellsToProcess += countNewCells;
		countCellsToProcess--;
		curIndexToRead++;
	}

	COORDS** res = (COORDS**)malloc(sizeof(COORDS*) * (*lenPath));
	createPathByWeight(h, w, lenPath, res);
	return res;
}

void createPathByWeight(int h, int w, int* lenPath, COORDS** res)
{

	int i, x, y;
	x = h - 1;
	y = w - 1;
	int lastValue = *lenPath;
	for (i = 0; i < *lenPath; i++)
	{
		res[i] = (COORDS*)malloc(sizeof(COORDS));

		res[i]->x = x;
		res[i]->y = y;

		if (x != 0 && canUp(labirint[x][y]) && labirint_values[x - 1][y] == lastValue - 1)
			x = x - 1;
		else if ((x != h - 1) && canDown(labirint[x][y]) && labirint_values[x + 1][y] == lastValue - 1)
			x = x + 1;
		else if ((y != w - 1) && canRight(labirint[x][y]) && labirint_values[x][y + 1] == lastValue - 1)
			y = y + 1;
		else if (y != 0 && canLeft(labirint[x][y]) && labirint_values[x][y - 1] == lastValue - 1)
			y = y - 1;

		lastValue--;
	}
}

int processCell(int x, int y, int h, int w, COORDS crds[], int startIndex)
{
	int count = 0;

	if ((x != h - 1) && canDown(labirint[x][y]) && (labirint_values[x + 1][y] == 0))
	{
		labirint_values[x + 1][y] = labirint_values[x][y] + 1;
		crds[startIndex].x = x + 1;
		crds[startIndex].y = y;
		startIndex++;
		count++;
	}

	if ((y != w - 1) && canRight(labirint[x][y]) && (labirint_values[x][y + 1] == 0))
	{
		labirint_values[x][y + 1] = labirint_values[x][y] + 1;
		crds[startIndex].x = x;
		crds[startIndex].y = y + 1;
		startIndex++;
		count++;
	}

	if (x != 0 && canUp(labirint[x][y]) && (labirint_values[x - 1][y] == 0))
	{
		labirint_values[x - 1][y] = labirint_values[x][y] + 1;
		crds[startIndex].x = x - 1;
		crds[startIndex].y = y;
		startIndex++;
		count++;
	}

	if (y != 0 && canLeft(labirint[x][y]) && (labirint_values[x][y - 1] == 0))
	{
		labirint_values[x][y - 1] = labirint_values[x][y] + 1;
		crds[startIndex].x = x;
		crds[startIndex].y = y - 1;
		startIndex++;
		count++;
	}

	return count;
}

void drawPath(COORDS** lcrs, int len)
{
	int i;
	for (i = 0; i < len; i++)
	{
		int curX = (lcrs[i]->x * 2) + 4;
		int curY = (lcrs[i]->y * 2) + 2;

		printf("\033[%d;%dH%c", curX, curY, '*');
		output[curX - 2][curY] = '*';
	}
}

void drawLabirint(int h, int w, int onlySaveInFile)
{
	int x, y;
	for (x = 0; x < h; x++)
	{
		for (y = 0; y < w; y++)
		{
			int curX = (x * 2) + 4;
			int curY = (y * 2) + 2;

			printCell(labirint[x][y], curX, curY, onlySaveInFile);
		}
	}
}

void printCell(char ch, int x, int y, int onlySaveInFile)
{
	char cell[3][4] = { "XXX","X X","XXX" };

	if (canUp(ch))
		cell[0][1] = ' ';

	if (canDown(ch))
		cell[2][1] = ' ';

	if (canRight(ch))
		cell[1][2] = ' ';

	if (canLeft(ch))
		cell[1][0] = ' ';


	if (onlySaveInFile != 1)
	{
		printf("\033[%d;%dH%s", x - 1, y - 1, cell[0]);	// set console coords
		printf("\033[%d;%dH%s", x, y - 1, cell[1]);
		printf("\033[%d;%dH%s", x + 1, y - 1, cell[2]);
	}

	int outX = 0;
	int outY = 0;
	x = x - 1;
	y = y - 1;

	for (; outX < 3; outX++, x++)
	{
		for (outY = 0; outY < 3; outY++, y++)
		{
			output[x - 2][y] = cell[outX][outY];
		}
		y = y - 3;
	}
}
