#pragma once

int sum(int n, int d, ...);
int arithmeticMean(int n, int d, ...);
int maxValue(int n, int d, ...);
int minValue(int n, int d, ...);