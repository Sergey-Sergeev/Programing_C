
#include <stdio.h>
#include <stdlib.h>
#include <vadefs.h>
#include <varargs.h>


int maxDouble(int a, int b)
{
	return a > b ? a : b;
}

int minDouble(int a, int b)
{
	return a < b ? a : b;
}


int sum(int n, int d, ...)
{
	int s = 0;
	va_list pl;

	va_start(pl, d);

	while (n-- > 0)
	{
		s += va_arg(pl, int);
	}
	va_end(pl);
	return s;
}

int arithmeticMean(int n, int d, ...)
{
	int s = 0;
	int cv = n;
	va_list pl;
	va_start(pl, d);

	while (n-- > 0)
	{
		s += va_arg(pl, int);
	}
	va_end(pl);
	return s / cv;
}

int maxValue(int n, int d, ...)
{
	int mx = 0;
	va_list pl;
	va_start(pl, d);

	n--;
	mx = va_arg(pl, int);

	while (n-- > 0)
	{
		mx = maxDouble(va_arg(pl, int), mx);
	}
	va_end(pl);
	return mx;
}

int minValue(int n, int d, ...)
{
	int mn = 0;
	va_list pl;
	va_start(pl, d);

	n--;
	mn = va_arg(pl, int);

	while (n-- > 0)
	{
		mn = minDouble(va_arg(pl, int), mn);
	}
	va_end(pl);
	return mn;
}