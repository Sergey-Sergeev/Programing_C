#pragma once


typedef struct graph {
	void** links;
	int linkCount;
	int x;
	int y;
	int maxLinksCount;
	int weight;
} GRAPH;


void add_graph_link(GRAPH** g, GRAPH* links);
GRAPH* create_graph(int x, int y, int maxLinksCount);
void del_graph(GRAPH** g);
int graph_len(GRAPH** g);
int searchShortestPath(GRAPH** g, GRAPH* graphPoint);
void freeGraph(GRAPH** gr);

//GRAPH* setGraphByArray(char (*arr)[], int w, int h);