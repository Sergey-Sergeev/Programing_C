#include "Graph.h"
#include <stdlib.h>
#include <stdio.h>


void add_graph_link(GRAPH** g, GRAPH* link)
{
	if (*g == NULL)
	{
		(*g) = link;
	}
	else
	{
		if ((*g)->linkCount == (*g)->maxLinksCount)
		{
			printf("set graph memory over its size");
			exit(1);
			return;
		}

		if ((*g)->linkCount == 0)
			(*g)->links = (void**)malloc(sizeof(GRAPH*) * (*g)->maxLinksCount);

		((GRAPH**)((*g)->links))[(*g)->linkCount++] = link;
	}
}

GRAPH* create_graph(int x, int y, int maxLinksCount)
{
	GRAPH* graph = (GRAPH*)malloc(sizeof(GRAPH));
	graph->x = x;
	graph->y = y;
	graph->maxLinksCount = maxLinksCount;
	graph->linkCount = 0;
	graph->links = NULL;
	graph->weight = 0;
	return graph;
}

void freeGraph(GRAPH** gr)
{
	if ((*gr)->linkCount != 0)
		free((*gr)->links);
	free(*gr);
}

void del_graph(GRAPH** g)
{
	int len = (*g)->linkCount;

	if (len == 0)
	{
		free(*g);
		return;
	}

	int i = 0;
	for (; i < len; i++)
	{
		del_graph(&(((GRAPH*)((*g)->links))[i]));
	}
}

int graph_len(GRAPH** g)
{
	if (*g == NULL)
		return 0;

	int sum = 1;

	int l = (*g)->linkCount;

	int i = 0;
	for (; i < l; i++)
	{
		sum += graph_len(&(((GRAPH*)((*g)->links))[i]));
	}

	return sum;
}

int searchShortestPath(GRAPH** g, GRAPH* graphPoint)
{
	if ((*g) == NULL)
		return 1;

	if (graphPoint->x == (*g)->x && graphPoint->y == (*g)->y)
		return (*g)->weight;

	int i = 0;
	int nextW = (*g)->weight + 1;
	for (; i < (*g)->linkCount; i++)
	{
		if (((GRAPH**)((*g)->links))[i]->weight == 0)
		{
			((GRAPH**)((*g)->links))[i]->weight = nextW;
		}
		else ((GRAPH**)((*g)->links))[i]->weight = min(nextW, ((GRAPH**)((*g)->links))[i]->weight);
	}

	int pathLen = INT_MAX;

	for (i = 0; i < (*g)->linkCount; i++)
	{
		if (((GRAPH**)((*g)->links))[i]->weight < (*g)->weight)
			continue;

		int nLen = searchShortestPath(&(((GRAPH**)((*g)->links))[i]), graphPoint);
		pathLen = min(nLen, pathLen);
	}

	if (pathLen == INT_MAX)
		(*g)->weight = INT_MAX;

	return pathLen;
}
