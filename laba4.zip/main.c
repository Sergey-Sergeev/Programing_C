#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <Windows.h>
#include "Graph.h"

#define BUFFER_SIZE	2001
#define MAX_POSSIBLE_WAYS_TO_MOVE	4

char labirint[BUFFER_SIZE][BUFFER_SIZE];
char output[BUFFER_SIZE][BUFFER_SIZE];

const char const UP_VALUES[9] = "02468ACE";
const char const DOWN_VALUES[9] = "012389AB";
const char const RIGHT_VALUES[9] = "014589CD";
const char const LEFT_VALUES[9] = "01234567";

typedef struct coords {
	int x;
	int y;
} COORDS;




int isContainIn(char c, const char const buff[])
{
	int i = 0;
	int len = strlen(buff);
	for (; i < len; i++)
	{
		if (buff[i] == c)
			return 1;
	}
	return 0;
}

int canUp(char c)
{
	return isContainIn(c, UP_VALUES);
}

int canDown(char c)
{
	return isContainIn(c, DOWN_VALUES);
}

int canRight(char c)
{
	return isContainIn(c, RIGHT_VALUES);
}

int canLeft(char c)
{
	return isContainIn(c, LEFT_VALUES);
}

void drawLabirint(int h, int w);
void printCell(char ch, int x, int y);
COORDS** wideSearch(int h, int w, int* lenPath, GRAPH* gr, GRAPH**** pgrs);
void drawPath(COORDS** lcrs, int len);
GRAPH* setGraphByArray(int w, int h, GRAPH**** pgrs);

int main()
{
	char path[201];
	path[200] = 0;
	printf("Enter the file path:  ");
	scanf("%200s", &path);
	OemToCharA(&path, &path);

	FILE* file = fopen(path, "r");
	FILE* outFile = fopen("output.txt", "w");

	int height, width;

	if (file != NULL && outFile != NULL && fscanf(file, "%d %d\n", &height, &width) == 2)
	{
		int x, y;
		char line[BUFFER_SIZE];

		for (x = 0; x < height; x++)
		{
			fgets(line, BUFFER_SIZE, file);

			for (y = 0; y < width; y++)
			{
				labirint[x][y] = line[y];
			}
		}

		for (x = 0; x < height * 3 + 2; x++)
		{
			memset(output[x], ' ', width);
		}


		int lenPath = 0;
		GRAPH*** pgrs;
		GRAPH* gr = setGraphByArray(height, width, &pgrs);
		COORDS** fastestPath = wideSearch(height, width, &lenPath, gr, &pgrs);

		drawLabirint(height, width);
		drawPath(fastestPath, lenPath);

		printf("\033[%d;%dH", height * 4, 0);
		printf("MIN:  [ %d ]\n", lenPath);


		for (x = 0; x < lenPath; x++)
			free(fastestPath[x]);
		free(fastestPath);

		x = 0;
		y = 0;
		for (; x < height; x++)
		{
			for (; y < width; y++)
			{
				freeGraph(&(pgrs[x][y]));
			}
			free(pgrs[x]);
		}
		free(pgrs);

		for (x = 0; x < height * 3 + 2; x++)
		{
			fprintf(outFile, "%s\n", output[x]);
		}
	}
	else
	{
		printf("Error to get height and width.");
	}

	fclose(file);
	fclose(outFile);

	return 0;
}

COORDS** wideSearch(int h, int w, int* lenPath, GRAPH* gr, GRAPH**** pgrs)
{
	gr->weight = 1;
	*lenPath = searchShortestPath(&gr, (*pgrs)[h - 1][w - 1]);
	COORDS** res = (COORDS**)malloc(sizeof(COORDS*) * (*lenPath));

	int i, x, y;
	x = h - 1;
	y = w - 1;
	int lastValue = *lenPath;
	for (i = 0; i < *lenPath; i++)
	{
		res[i] = (COORDS*)malloc(sizeof(COORDS));

		res[i]->x = x;
		res[i]->y = y;

		if (x != 0 && canUp(labirint[x][y]) && (*pgrs)[x - 1][y]->weight == lastValue - 1)
			x = x - 1;
		else if ((x != h - 1) && canDown(labirint[x][y]) && (*pgrs)[x + 1][y]->weight == lastValue - 1)
			x = x + 1;
		else if ((y != w - 1) && canRight(labirint[x][y]) && (*pgrs)[x][y + 1]->weight == lastValue - 1)
			y = y + 1;
		else if (y != 0 && canLeft(labirint[x][y]) && (*pgrs)[x][y - 1]->weight == lastValue - 1)
			y = y - 1;

		lastValue--;
	}

	return res;
}

GRAPH* setGraphByArray(int h, int w, GRAPH**** pgrs)
{
	int x, y, i;

	*pgrs = (GRAPH***)malloc(sizeof(GRAPH**) * h);
	for (x = 0; x < h; x++)
	{
		(*pgrs)[x] = (GRAPH**)malloc(sizeof(GRAPH*) * w);

		for (y = 0; y < w; y++)
		{
			(*pgrs)[x][y] = create_graph(x, y, MAX_POSSIBLE_WAYS_TO_MOVE);
		}
	}

	for (x = 0; x < h; x++)
	{
		for (y = 0; y < w; y++)
		{
			char ch = labirint[x][y];

			if ((x != h - 1) && canDown(ch))
				add_graph_link(&((*pgrs)[x][y]), (*pgrs)[x + 1][y]);

			if ((y != w - 1) && canRight(ch))
				add_graph_link(&((*pgrs)[x][y]), (*pgrs)[x][y + 1]);

			if ((x != 0) && canUp(ch))
				add_graph_link(&((*pgrs)[x][y]), (*pgrs)[x - 1][y]);

			if ((y != 0) && canLeft(ch))
				add_graph_link(&((*pgrs)[x][y]), (*pgrs)[x][y - 1]);
		}
	}

	return (*pgrs)[0][0];
}

int minValueCell(int cell, int cellOther)
{
	if (cell == 0)
		return cellOther;
	return min(cell, cellOther);
}

void drawPath(COORDS** lcrs, int len)
{
	int i;
	for (i = 0; i < len; i++)
	{
		int curX = (lcrs[i]->x * 3) + 4;
		int curY = (lcrs[i]->y * 3) + 2;

		printf("\033[%d;%dH%c", curX, curY, '*');
		output[curX - 2][curY] = '*';
	}
}

void drawLabirint(int h, int w)
{
	int x, y;
	for (x = 0; x < h; x++)
	{
		for (y = 0; y < w; y++)
		{
			int curX = (x * 3) + 4;
			int curY = (y * 3) + 2;

			printCell(labirint[x][y], curX, curY);
		}
	}
}

void printCell(char ch, int x, int y)
{
	char cell[3][4] = { "XXX","X X","XXX" };

	if (canUp(ch))
		cell[0][1] = ' ';

	if (canDown(ch))
		cell[2][1] = ' ';

	if (canRight(ch))
		cell[1][2] = ' ';

	if (canLeft(ch))
		cell[1][0] = ' ';


	printf("\033[%d;%dH%s", x - 1, y - 1, cell[0]);	// set console coords
	printf("\033[%d;%dH%s", x, y - 1, cell[1]);
	printf("\033[%d;%dH%s", x + 1, y - 1, cell[2]);

	int outX = 0;
	int outY = 0;
	x = x - 1;
	y = y - 1;

	for (; outX < 3; outX++, x++)
	{
		for (outY = 0; outY < 3; outY++, y++)
		{
			output[x - 2][y] = cell[outX][outY];
		}
		y = y - 3;
	}
}
