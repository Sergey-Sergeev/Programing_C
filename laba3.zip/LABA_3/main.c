#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include "list.h"
#include <locale.h>
#include <iconv.h>

#define max(a,b)	((a) > (b) ? (a) : (b))
#define MAX_PATH_LEN	1000
#define MAX_BUFFER_LEN 1000

struct Book;

struct tnode
{
	struct Book* book;
	struct tnode* lchild, * rchild;
};

typedef struct Book
{
	char* author;
	char* title;
	char* publisher;
	int bookNumber;
	char* isbn;
	int year;
	char* series;
	char* edition;
	char* volume;
	char* url;
} BOOK;

void DeleteFirstCharInStr(char* str);
char* CopyStr(char* str);
void CopyStrToDest(char** dest, char* source);
char* convertToCP1251(char* str);
int tree_height(struct tnode* p);
int tree_nodes(struct tnode* p);
void connectStr(char** dest, char* sourse1, char* sourse2, char* source3);
int tree_find(struct tnode* p, char* nameOfAuthor, NODE** out);

struct tnode* tree_insert(struct tnode* p, BOOK* book)
{
	if (p == NULL)  // создаем узел
	{
		p = (struct tnode*)malloc(sizeof(struct tnode)); /* insert the new node as root node*/
		if (p == NULL)
		{
			printf("Cannot allocate\n");  exit(0);
		}
		p->book = book;
		p->lchild = p->rchild = NULL;

		return p;
	}

	int sortVal = strncmp(book->author, p->book->author, 4);

	if (sortVal > 0)
	{
		p->rchild = tree_insert(p->rchild, book);
		return p;
	}
	else if (sortVal < 0)
	{
		p->lchild = tree_insert(p->lchild, book);
		return p;
	}
	else
	{
		sortVal = strncmp(book->title, p->book->title, 4);

		if (sortVal >= 0)
		{
			p->rchild = tree_insert(p->rchild, book);
			return p;
		}
		else
		{
			p->lchild = tree_insert(p->lchild, book);
			return p;
		}
	}
	return p;
}
/* a function to binary tree in inorder */
void tree_print(struct tnode* p)
{
	if (p != NULL)
	{
		tree_print(p->lchild);
		printf("\n[book: (%d)]\n\tauthor:  [%s]\n\ttitle:  [%s]", p->book->bookNumber, p->book->author, p->book->title);
		tree_print(p->rchild);
	}
}

int tree_find(struct tnode* p, char* nameOfAuthor, NODE** out)
{
	if (p == NULL)
		return -1;

	int sortVal = strncmp(nameOfAuthor, p->book->author, 5);//strlen(nameOfAuthor));

	if (sortVal == 0)
	{
		NODE* d = (NODE*)malloc(sizeof(NODE));
		d->data = (void*)(p->book);
		add_node(out, d);
	}

	if (sortVal >= 0)
		tree_find(p->rchild, nameOfAuthor, out);
	if (sortVal <= 0)
		tree_find(p->lchild, nameOfAuthor, out);

	return (int)(-(list_len(out) == 0));
}

int tree_height(struct tnode* p)
{
	int height;
	if (p->lchild == NULL && p->rchild == NULL)
		height = 1;
	else
	{
		int lh = 0, rh = 0;
		if (p->lchild != NULL)
			lh = tree_height(p->lchild) + 1;
		if (p->rchild != NULL)
			rh = tree_height(p->rchild) + 1;
		height = max(lh, rh);
	}
	return height;
}

int tree_nodes(struct tnode* p)
{
	if (p == NULL)
		return 0;
	if (p->lchild == NULL && p->rchild == NULL)
		return 1;
	else
	{
		int sum = 1;
		sum += tree_nodes(p->lchild);
		sum += tree_nodes(p->rchild);
		return sum;
	}
}


int get_all_files(char* pathOnly, char*** filePathes)
{
	NODE* list = NULL;
	int count = 0;
	WIN32_FIND_DATA FindFileData;
	HANDLE handle;

	int pathOnlyLen = strlen(pathOnly);
	char* path = (char*)malloc(sizeof(char) * (pathOnlyLen + 3));
	path = strcpy(path, pathOnly);
	path[pathOnlyLen] = '\\';
	path[pathOnlyLen + 1] = '*';
	path[pathOnlyLen + 2] = 0;

	handle = FindFirstFile(path, &FindFileData);

	if (handle == INVALID_HANDLE_VALUE)
	{
		printf("Cant find file:  [%d]\n", GetLastError());
		return -1;
	}

	while (FindNextFileA(handle, &FindFileData)) {
		if (FindFileData.dwFileAttributes == FILE_ATTRIBUTE_DIRECTORY)
		{
			if (FindFileData.cFileName[0] == '.') continue;
			int dirNameLen = strlen(FindFileData.cFileName);
			char* pathToNewDir = (char*)malloc(sizeof(char) * (pathOnlyLen + dirNameLen + 2));
			pathToNewDir = strcpy(pathToNewDir, pathOnly);

			int i, j;
			pathToNewDir[pathOnlyLen] = '\\';
			for (i = pathOnlyLen + 1, j = 0; j < dirNameLen; i++, j++)
			{
				pathToNewDir[i] = FindFileData.cFileName[j];
			}
			pathToNewDir[pathOnlyLen + dirNameLen + 1] = 0;

			char** subFileNames = NULL;
			int fileCount = get_all_files(pathToNewDir, &subFileNames);

			for (i = 0; i < fileCount; i++)
			{
				NODE* newNode = (NODE*)malloc(sizeof(NODE));
				char* fileName;
				int namelen = strlen(subFileNames[i]);
				count++;

				if ((fileName = (char*)malloc(sizeof(char) * (namelen + 1))) == NULL)
					perror("Cant to allocate memory");

				fileName[namelen] = 0;
				fileName = strcpy(fileName, subFileNames[i]);

				newNode->data = (void*)fileName;
				add_node(&list, newNode);
				free(subFileNames[i]);
			}
			free(subFileNames);
			continue;
		}

		NODE* newNode = (NODE*)malloc(sizeof(NODE));
		char* fileName;
		int namelen = strlen(FindFileData.cFileName);
		count++;

		if ((fileName = (char*)malloc(sizeof(char) * (namelen + 1))) == NULL)
			perror("Cant to allocate memory");

		fileName[namelen] = 0;
		fileName = strcpy(fileName, FindFileData.cFileName);

		newNode->data = (void*)fileName;
		add_node(&list, newNode);
	}

	FindClose(handle);

	*filePathes = (char**)malloc(sizeof(char*) * count);

	int i = 0;
	for (; i < count; i++)
	{
		char* fileName = (char*)(get_node(&list, i)->data);
		int fileNameLen = strlen(fileName);
		int len = fileNameLen + pathOnlyLen;

		if (strncmp(fileName, pathOnly, pathOnlyLen) != 0)
		{
			char* fullPathFileName = (char*)malloc(sizeof(char) * (len + 2));
			(*filePathes)[i] = (char*)malloc(sizeof(char) * (len + 2));

			fullPathFileName[len + 1] = 0;
			connectStr(&fullPathFileName, pathOnly, "\\", fileName);
			(*filePathes)[i] = strcpy((*filePathes)[i], fullPathFileName);
			free(fullPathFileName);
		}
		else
		{
			(*filePathes)[i] = (char*)malloc(fileNameLen + 1);
			(*filePathes)[i][fileNameLen] = 0;
			(*filePathes)[i] = strcpy((*filePathes)[i], fileName);
		}
	}

	freeList(&list);
	free(path);
	return count;
}

void connectStr(char** dest, char* source1, char* source2, char* source3)
{
	int i, j;
	for (i = 0; i < strlen(source1); i++)
	{
		(*dest)[i] = source1[i];
	}

	for (j = 0; j < strlen(source2); i++, j++)
	{
		(*dest)[i] = source2[j];
	}

	for (j = 0; j < strlen(source3); i++, j++)
	{
		(*dest)[i] = source3[j];
	}

}

int get_book_data(char* path, BOOK** book)
{
	FILE* file = fopen(path, "r");

	if (file == NULL)
		return -1;

	char authorTempBuff[MAX_BUFFER_LEN];
	char titleTempBuff[MAX_BUFFER_LEN];
	char publisherTempBuff[MAX_BUFFER_LEN];
	int bookNumberTemp;
	char isbnTempBuff[MAX_BUFFER_LEN];
	char yearTempBuff[11];
	char seriesTempBuff[MAX_BUFFER_LEN];
	char editionTempBuff[MAX_BUFFER_LEN];
	char volumeTempBuff[MAX_BUFFER_LEN];
	char urlTempBuff[MAX_BUFFER_LEN];

	if (
		fscanf(file,
			//	"@book{book:%d,\n   title =     {%[^}]},\n   author = {%[^}]},\n   publisher = {%[^}]},\n   isbn =      {%[^}]},\n   year =      {%d},\n   series =    {%[^}]},\n   edition =   {%[^}]},\n   volume =    {%[^}]},\n   url =       {%[^}]},\n",
			"@book{book:%d,\n   title =     %[^}]},\n   author =    %[^}]},\n   publisher = %[^}]},\n   isbn =      %[^}]},\n   year =      %[^}]},\n   series =    %[^}]},\n   edition =   %[^}]},\n   volume =    %[^}]},\n   url =       %[^}]},\n",
			&bookNumberTemp, &titleTempBuff, &authorTempBuff, &publisherTempBuff, &isbnTempBuff, &yearTempBuff, &seriesTempBuff, &editionTempBuff, &volumeTempBuff, &urlTempBuff)
		== 10)
	{
		DeleteFirstCharInStr(&titleTempBuff);
		DeleteFirstCharInStr(&authorTempBuff);
		DeleteFirstCharInStr(&publisherTempBuff);
		DeleteFirstCharInStr(&isbnTempBuff);
		DeleteFirstCharInStr(&seriesTempBuff);
		DeleteFirstCharInStr(&editionTempBuff);
		DeleteFirstCharInStr(&volumeTempBuff);
		DeleteFirstCharInStr(&urlTempBuff);

		CopyStrToDest(&((*book)->title), &titleTempBuff);
		CopyStrToDest(&((*book)->author), &authorTempBuff);
		CopyStrToDest(&((*book)->publisher), &publisherTempBuff);
		CopyStrToDest(&((*book)->isbn), &isbnTempBuff);
		CopyStrToDest(&((*book)->series), &seriesTempBuff);
		CopyStrToDest(&((*book)->edition), &editionTempBuff);
		CopyStrToDest(&((*book)->volume), &volumeTempBuff);
		CopyStrToDest(&((*book)->url), &urlTempBuff);

		if (strlen(yearTempBuff) > 1)
		{
			char* ptr = yearTempBuff + 1;
			(*book)->year = atoi(ptr);
		}
		else (*book)->year = 0;

		(*book)->bookNumber = bookNumberTemp;

		(*book)->title = convertToCP1251((*book)->title);
		(*book)->author = convertToCP1251((*book)->author);
		(*book)->publisher = convertToCP1251((*book)->publisher);
		(*book)->series = convertToCP1251((*book)->series);
		(*book)->edition = convertToCP1251((*book)->edition);
		(*book)->volume = convertToCP1251((*book)->volume);

		fclose(file);
		return 0;
	}
	else
	{
		fclose(file);
		return -1;
	}
}

void DeleteFirstCharInStr(char* str)
{
	str = strncpy(str, str + 1, strlen(str));
}

void CopyStrToDest(char** dest, char* source)
{
	if (source == NULL)
	{
		*dest = "NULL";
		return;
	}
	int len = strlen(source);
	*dest = (char*)malloc(sizeof(char) * (len + 1));
	(*dest)[len] = 0;
	*dest = strcpy(*dest, source);
}

char* CopyStr(char* str)
{
	int len = strlen(str);
	char* n = (char*)malloc(sizeof(char) * (len + 1));
	n = strcpy(n, str);
	return n;
}

void free_2d_str_array(char*** arr, int len)
{
	int i;
	for (i = 0; i < len; i++)
	{
		free((*arr)[i]);
	}
	free(*arr);
}

char* convertToCP1251(char* str)
{
	size_t strLen = strlen(str);
	iconv_t cd;
	const char* in = str;
	char* buf = (char*)malloc(sizeof(char) * (strLen + 1));
	memset(buf, 0, strLen + 1);
	char* out = buf;

	cd = iconv_open("cp1251", "UTF-8");

	if (cd == (iconv_t)(-1)) {
		free(buf);
		printf("iconv_open error");
		return NULL;
	}

	size_t lenOut = strLen + 1;
	iconv(cd, &str, &strLen, &out, &lenOut);

	iconv_close(cd);
	//free(*str);
	return buf;
}

void saveSortedData(FILE* file, struct tnode* tree)
{
	if (file == NULL)
	{
		printf("Error to save output data.\n");
		return;
	}

	if ((tree == NULL) || (tree->book == NULL))
		return;

	if (tree->lchild != NULL)
		saveSortedData(file, tree->lchild);

	//if ((tree->lchild == NULL) && (tree->rchild == NULL))
	//{
	fprintf(file,
		"@book{book:%d,\n   title =     {%s},\n   author =    {%s},\n   publisher = {%s},\n   isbn =      {%s},\n   year =      {%d},\n   series =    {%s},\n   edition =   {%s},\n   volume =    {%s},\n   url =       {%s},\n",
		tree->book->bookNumber, tree->book->title, tree->book->author, tree->book->publisher, tree->book->isbn, tree->book->year, tree->book->series, tree->book->edition, tree->book->volume, tree->book->url);

	if (tree->rchild != NULL)
		saveSortedData(file, tree->rchild);
	//}
}

void printList(NODE* list, char* format)
{
	int len = list_len(&list);
	int i;
	for (i = 0; i < len; i++)
	{
		printf(format, (char*)(get_node(&list, i)->data));
	}
}

int main()
{
	setlocale(LC_ALL, "rus");
	struct tnode* root = NULL;
	char path[MAX_PATH_LEN];
	printf("Enter the directory path:  \n");
	scanf("%999s", path);

	OemToCharA(path, path);

	char** filePathes;
	int filesCount = get_all_files(path, &filePathes);

	system("cls");	// clear console
	printf("SCAN FILES AT:  [%s]\n", path);


	int lastPathLen = 0;
	int lastdiff = 0;
	char* spaces = (char*)malloc(sizeof(char) * (MAX_PATH_LEN + 1));
	spaces[MAX_PATH_LEN] = 0;
	memset(spaces, ' ', MAX_PATH_LEN);


	NODE* listFailBooks = NULL;

	int i = 0;
	for (; i < filesCount; i++)
	{
		printf("\033[%d;%dH", 2, 0);	// set console coords
		printf("PROCESS FILE:  [%s]   ( %d/%d )%s", filePathes[i], i + 1, filesCount, spaces);

		int tempLen = strlen(filePathes[i]);
		if (tempLen - lastPathLen > 0)
		{
			spaces[lastdiff] = ' ';
			lastdiff = tempLen - lastPathLen;

			if (lastdiff > MAX_PATH_LEN)
				lastdiff = MAX_PATH_LEN;

			spaces[lastdiff] = 0;
			lastPathLen = tempLen;
		}

		BOOK* book = (BOOK*)malloc(sizeof(BOOK));
		int res = get_book_data(filePathes[i], &book);
		if (res == 0)
		{
			root = tree_insert(root, book);
			//cnt++;
		}
		else
		{
			printf("\n\nCant to parse Book [ %d ]\n", i);
			NODE* n = (NODE*)malloc(sizeof(NODE));
			n->data = (void*)(CopyStr(filePathes[i]));
			add_node(&listFailBooks, n);
		}
	}

	printf("\n\nCant to parse:\n");
	printList(listFailBooks, "[ %s ]\n");

	printf("\nSuccessfully parsed:  [%d]", tree_nodes(root));

	free(spaces);
	freeList(&listFailBooks);
	free_2d_str_array(&filePathes, filesCount);

	FILE* file = fopen("data.txt", "w");
	saveSortedData(file, root);
	fclose(file);

	//tree_print(root);
	while (1)
	{
		printf("\n\nEnter the name of author to find it:  ");
		char name[MAX_BUFFER_LEN];
		scanf("  %[^\n]", name);
		OemToCharA(name, name);

		NODE* listFind = NULL;
		int res = tree_find(root, name, &listFind);

		if (res == 0)
		{
			int i;
			for (i = 0; i < list_len(&listFind); i++)
			{
				BOOK* fbook = (BOOK*)(get_node(&listFind, i)->data);
				printf("Find:\n");
				printf("\n@book{book:%d,\n   title =     {%s},\n   author =    {%s},\n   publisher = {%s},\n   isbn =      {%s},\n   year =      {%d},\n   series =    {%s},\n   edition =   {%s},\n   volume =    {%s},\n   url =       {%s},\n",
					fbook->bookNumber, fbook->title, fbook->author, fbook->publisher, fbook->isbn, fbook->year, fbook->series, fbook->edition, fbook->volume, fbook->url);
			}
		}
		else
		{
			printf("Nothing find.\n");
		}

		printf("\nContinue? (y/n):  ");
		char ich;
		while (1)
		{
			ich = getch();
			if (ich == 'y')
				break;
			if (ich == 'n')
				goto exit;
		}
	}

exit:;
	putchar('\n');
	fflush(stdout);
}



/*

Данна программа принимает на вход путь к директории где находятся файлы(включая все подпапки).
На выход программа создаёт файл или перезаписывает его, елси он уже существует,
в котором будут все книги расположенные в алфавитном порядке.

Для перевода русских букв с файла была использована библиотека iconv.h, для перевода русских букв с консоли функция OemToCharA().

Алгоритм поиска, нахождения высоты дерева, колчества ветвей реализованы.

Весь код включая файлы list.h, list.c я написал с нуля сам и могу объяснить смысл каждой строчки.


*/

