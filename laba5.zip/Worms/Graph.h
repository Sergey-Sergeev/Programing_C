#pragma once
#include "list.h"




typedef struct graph {
	NODE* links;
	int listLen;
	int x;
	int y;
	int weight;
} GRAPH;


void add_graph_link(GRAPH** g, GRAPH* links);
GRAPH* create_graph(int x, int y, int weight);
void del_graph(GRAPH** g);
