#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <Windows.h>
#include "list.h"


typedef struct coords {
	int x;
	int y;
	int weight;
} COORDS;


int getMaxWorms(NODE** graph, int N, int wormLen, int startIndexX, int startIndexY, int* remain);
int readValueFromFile(FILE* file);

int main(int argc, char* argv[])
{
	FILE* FOUT = fopen("output.txt", "w");
	int i, k, j;
	for (j = 1; j < argc; j++)
	{
		OemToCharA(argv[j], argv[j]);

		FILE* FIN = fopen(argv[j], "r");
		//FILE* FIN = fopen("C:\\Users\\������������\\source\\repos\\Worms\\x64\\Debug\\in.txt", "r");

		if (FIN == NULL)
		{
			printf("Cant to open file:  [%s]\n", argv[j]);
			continue;
		}

		int N, L;

		if (fscanf(FIN, "%d %d\n", &N, &L) != 2)
		{
			printf("Fail to read file:  [%s]\n", argv[j]);
			fclose(FIN);
			continue;
		}


		char* line;

		int* arr1 = (int*)malloc(sizeof(int) * N);
		NODE** listOfLists = (NODE**)malloc(sizeof(NODE*) * N);

		for (i = 0; i < N; i++)
		{
			listOfLists[i] = NULL;
		}


		for (i = 0; i < N - 1; i++)
			arr1[i] = readValueFromFile(FIN);


		for (i = 0; i < N - 1; i++)
		{
			int weight = readValueFromFile(FIN);

			NODE* n = (NODE*)malloc(sizeof(NODE));

			COORDS* coords = (COORDS*)malloc(sizeof(COORDS));
			coords->x = arr1[i];
			coords->y = i + 1;
			coords->weight = weight;

			n->data = (void*)(coords);
			n->next = NULL;

			add_node(&(listOfLists[arr1[i]]), n);
		}

		free(arr1);

		int maxWorms = 0;
		maxWorms = getMaxWorms(listOfLists, N, L, 0, 0, &maxWorms);

		printf("Max: [ %d ]", maxWorms);
		fprintf(FOUT, "%d", maxWorms);


		for (i = 0; i < N; i++)
			freeList(&(listOfLists[i]));
		free(listOfLists);


		fclose(FIN);
	}

	fclose(FOUT);

	return 0;
}

int readValueFromFile(FILE* file)
{
	char arr[12];
	int i = 0;

	char ch;
	while ((ch = fgetc(file)) != -1 && ch != '\n' && ch != ' ')
	{
		arr[i++] = ch;
	}
	arr[i] = 0;
	return atoi(arr);
}


int getMaxWorms(NODE** listOfLists, int N, int wormLen, int startIndexX, int curWeight, int* remain)
{
	int i = 0, wc = 0, maxRemain = 0;

	NODE* curList = listOfLists[startIndexX];
	int curLen = list_len(&curList);

	for (i = 0; i < curLen; i++)
	{
		COORDS* cds = (COORDS*)(get_node(&curList, i)->data);

		int remainLast = 0;
		int val = getMaxWorms(listOfLists, N, wormLen, cds->y, cds->weight, &remainLast);
		wc += val;
		maxRemain = max(maxRemain, remainLast);
	}

	int wormsCount = curWeight / wormLen;
	int remainCur = curWeight - wormsCount * wormLen;

	wormsCount += ((remainCur + maxRemain) / wormLen);
	remainCur = ((remainCur + maxRemain) % wormLen);

	wc += wormsCount;
	*remain = remainCur;
	return wc;
}