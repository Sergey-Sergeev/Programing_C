#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <Windows.h>
#include <stdint.h>


void shortenFraction(uint64_t n, uint64_t d, uint64_t* outN, uint64_t* outD);

int main(int argc, char* argv[])
{
	FILE* FOUT = fopen("output.txt", "w");
	int i;
	for (i = 1; i < argc; i++)
	{
		OemToCharA(argv[i], argv[i]);

		FILE* FIN = fopen(argv[i], "r");

		if (FIN == NULL)
		{
			printf("Cant to open file:  [%s]\n", argv[i]);
			continue;
		}

		uint64_t N, M;

		if (fscanf(FIN, "%lld %lld", &N, &M) != 2)
		{
			printf("Fail to read file:  [%s]\n", argv[i]);
			fclose(FIN);
			continue;
		}


		uint64_t numerator = N * M;
		uint64_t denominator = M - N;

		shortenFraction(numerator, denominator, &numerator, &denominator);

		printf("\n%lld/%lld", numerator, denominator);
		fprintf(FOUT, "%lld/%lld\n", numerator, denominator);


		fclose(FIN);
	}

	fclose(FOUT);

	return 0;
}

void shortenFraction(uint64_t n, uint64_t d, uint64_t* outN, uint64_t* outD)
{
	uint64_t i;
	uint64_t minV = min(n, d);
	for (i = 2; i <= minV; i++)
	{
		while ((n % i == 0) && (d % i == 0))
		{
			n = n / i;
			d = d / i;
		}
	}
	*outN = n;
	*outD = d;
}