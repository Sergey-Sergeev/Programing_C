#define _CRT_SECURE_NO_WARNINGS		// ����� ���������� �� ������� �� ������������� ������� scanf

#include <stdio.h>
#include <stdlib.h>
#include <locale.h> 
#include <windows.h>
#include <stdbool.h>

#include "list.h"

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

/*
������� ��������� ���� � ��������, ���������� ���/������� ��������,
��� ��������, ��� � ���� (� ������). ����������� �������� �� ���� ��������,
���-��/�������, ���� ��� �����. ������� ���������. ������� �������,
�� �������� ������� �����������, ����� �������.
� ����� ����������� ����������� �������� ��������� ����� ��� ��������������.
*/

#define MAX_NAME_LEN 1000
#define MAX_BUFFER_LEN	1000

typedef struct Person
{
	char* name;
	char* surname;
	int year;
	int height;
	char* sex;
} PERSON;


typedef struct tree
{
	PERSON* person;
	struct tree* rch;
	struct tree* lch;
} TREE;

const int const SORT_PARAMETERS_LEN = 5;
const int ALL_SORT_PARAMETERS[] = {
	0, 1, 2, 3, 4, 5
};
const char* const SORT_PARAMETERS[] = {
	"NAME",
	"SURNAME",
	"YEAR",
	"HEIGHT",
	"SEX"
};

void printListOfPerson(NODE* list);
void freeListOfPeople(NODE** list);
int* parseParameters(char* str, int* outLen, int maxParametersCount);
NODE* sortByParameters(NODE* list, int* parameters, int paramLen);
NODE* convertTreeToList(TREE** tree, NODE** list);
char* getParameterByIndex(int i, PERSON* per);
char* convStrToInt(int val);
NODE* parseDataFromFile(FILE* SRC);
bool tryToOpenFile(FILE** SRC, char* path);
void add_treeNode(TREE** tree, PERSON* p, int* parameters, int paramLen);
PERSON* copyPerson(PERSON* p);
char* cpyStr(char* s);
bool isAllParametersExists(int* parameters, int lenIn, int* allParameters, int lenConst);


int laba8() {
	setlocale(LC_ALL, "Russian");

	FILE* SRC;// = fopen("C:\\Users\\������������\\Desktop\\src.txt", "r");

	{
		char path[1001];
		printf("Enter the path of the source file:  ");
		do
		{
			scanf("%1000s", path);
			OemToCharA(path, path);
		} while (!tryToOpenFile(&SRC, path));
	}

	NODE* list = parseDataFromFile(SRC);

	printListOfPerson(list);

	while (1)
	{
		int i = 0;
		for (i = 0; i < SORT_PARAMETERS_LEN; i++)
		{
			printf("[%d]: '%s'  ", i, SORT_PARAMETERS[i]);
		}
		printf("\n");

		int lenParameters = 0;
		int* parameters;
		while (1) {
			printf("Enter the sort parameters with devider ',': \n");
			char str[MAX_BUFFER_LEN];
			scanf(" %[^\n]", str);

			parameters = parseParameters(str, &lenParameters, SORT_PARAMETERS_LEN);
			if (lenParameters == 0)
			{
				printf("There is not a parameters( ex: 1,2,3...)\n");
			}
			else
			{
				if (isAllParametersExists(parameters, lenParameters, ALL_SORT_PARAMETERS, SORT_PARAMETERS_LEN))
					break;
				else printf("This is not a valid parameters.\n");
			}
		}

		for (i = 0; i < lenParameters; i++)
		{
			printf("->  %s  ", SORT_PARAMETERS[parameters[i]]);
		}

		NODE* sortedList = sortByParameters(list, parameters, lenParameters);
		printListOfPerson(sortedList);
		freeListOfPeople(&sortedList);

		printf("Continue? (y/n):  ");
		while (1)
		{
			char c = getchar();
			if (c == 'y')
				break;
			if (c == 'n')
				goto exit;
		}
	}

exit:;
	freeListOfPeople(&list);
	fclose(SRC);
	return 0;
}

bool isAllParametersExists(int* parameters, int lenIn, int* allParameters, int lenConst)
{
	int i = 0;
	int j = 0;
	for (; i < lenIn; i++)
	{
		bool flag = false;
		for (; j < lenConst; j++)
		{
			if (parameters[i] == allParameters[j])
			{
				flag = true;
				break;
			}
		}

		if (!flag)
			return false;
	}
	return true;
}

void printListOfPerson(NODE* list)
{
	int i = 0;
	for (; i < list_len(&list); i++)
	{
		PERSON* person = (PERSON*)((get_node(&list, i))->data);
		printf("\n>-------------------<\n[ PERSON %d ]\nNAME:  %s,\nSURNAME:  %s,\nYEAR:  %d,\nHEIGHT:  %d,\nSEX:  %s;\n>-------------------<\n",
			i, person->name, person->surname, person->year, person->height, person->sex);
	}
}

void freeListOfPeople(NODE** list)
{
	int len = list_len(list);

	int i = 0;
	for (; i < len; i++)
	{
		PERSON* p = (PERSON*)((get_node(list, i))->data);
		free(p->name);
		free(p->surname);
		free(p->sex);
	}
	freeList(list);
}

int* parseParameters(char* str, int* outLen, int maxParametersCount)
{
	int* res = (int*)malloc(sizeof(int) * maxParametersCount);
	char* tok = strtok(str, ",");
	int i = 0;
	while (tok != NULL && maxParametersCount != i)
	{
		int val = atoi(tok);
		res[i++] = val;
		tok = strtok(NULL, " .-,");
	}
	*outLen = i;
	return res;
}

NODE* sortByParameters(NODE* list, int* parameters, int paramLen)
{
	int sortListLen = list_len(&list);

	TREE* tree = NULL;
	int i = 0;
	for (; i < sortListLen; i++)
	{
		add_treeNode(&tree, (PERSON*)(get_node(&list, i)->data), parameters, paramLen);
	}

	NODE* sl = NULL;
	sl = convertTreeToList(&tree, &sl);

	return sl;
}

NODE* convertTreeToList(TREE** tree, NODE** list)
{
	if ((*tree)->rch != NULL)
		convertTreeToList(&((*tree)->rch), list);

	NODE* dat = (NODE*)malloc(sizeof(NODE));
	dat->data = (void*)((*tree)->person);
	add_node(list, dat);

	if ((*tree)->lch != NULL)
		convertTreeToList(&((*tree)->lch), list);

	return *list;
}

char* getParameterByIndex(int i, PERSON* per)
{
	if (i == 0)
		return per->name;
	else if (i == 1)
		return per->surname;
	else if (i == 2)
		return convStrToInt(per->year);
	else if (i == 3)
		return convStrToInt(per->height);
	else if (i == 4)
		return per->sex;
	else return NULL;
}

char* convStrToInt(int val)
{
	int len = 0;
	int tempVal = val;
	while (tempVal != 0)
	{
		len++;
		tempVal = tempVal / 10;
	}

	char* res = (char*)malloc(sizeof(char) * (len + 1));

	sprintf(res, "%d", val);
	return res;
}

NODE* parseDataFromFile(FILE* SRC)
{
	NODE* listOfPeople = NULL;

	char name[MAX_NAME_LEN];
	char surname[MAX_NAME_LEN];
	int year;
	char sex[7];	//	male / female
	int height;

	while (fscanf(SRC, "%s %s %d %s %d", name, surname, &height, sex, &year) == 5)
	{
		NODE* person = (NODE*)malloc(sizeof(NODE));
		person->data = NULL;
		person->next = NULL;
		PERSON* tempPerson = (PERSON*)malloc(sizeof(PERSON));

		int nameLen = strlen(name);
		int surnameLen = strlen(surname);
		int sexLen = strlen(sex);

		tempPerson->name = (char*)malloc(sizeof(char) * (nameLen + 1));
		tempPerson->surname = (char*)malloc(sizeof(char) * (surnameLen + 1));
		tempPerson->sex = (char*)malloc(sizeof(char) * (sexLen + 1));

		tempPerson->name[nameLen] = 0;
		tempPerson->surname[surnameLen] = 0;
		tempPerson->sex[sexLen] = 0;

		tempPerson->name = strcpy(tempPerson->name, name);
		tempPerson->surname = strcpy(tempPerson->surname, surname);
		tempPerson->sex = strcpy(tempPerson->sex, sex);

		tempPerson->height = height;
		tempPerson->year = year;

		person->data = (void*)tempPerson;

		add_node(&listOfPeople, person);
	}

	return listOfPeople;
}

bool tryToOpenFile(FILE** SRC, char* path)
{
	*SRC = fopen(path, "r");
	if (SRC == NULL)
	{
		printf("Fail to open file on: [ %s ]\n", path);
		return false;
	}

	return true;
}

void add_treeNode(TREE** tree, PERSON* p, int* parameters, int paramLen)
{
	if (*tree == NULL)
	{
		*tree = (TREE*)malloc(sizeof(TREE));
		PERSON* cpyPerson = copyPerson(p);
		(*tree)->person = cpyPerson;
		(*tree)->lch = (*tree)->rch = NULL;
	}
	else
	{
		int i = 0;
		for (; i < paramLen; i++)
		{
			char* paramNew = getParameterByIndex(parameters[i], p);
			char* paramExist = getParameterByIndex(parameters[i], (*tree)->person);

			int sortValue = strncmp(paramNew, paramExist, strlen(paramNew));

			if (sortValue > 0)
			{
				add_treeNode(&((*tree)->rch), p, parameters, paramLen);
				return;
			}
			else if (sortValue < 0)
			{
				add_treeNode(&((*tree)->lch), p, parameters, paramLen);
				return;
			}
		}

		add_treeNode(&((*tree)->rch), p, parameters, paramLen);
	}
}

PERSON* copyPerson(PERSON* p)
{
	PERSON* cpyPerson = (PERSON*)malloc(sizeof(PERSON));

	cpyPerson->name = cpyStr(p->name);
	cpyPerson->surname = cpyStr(p->surname);
	cpyPerson->sex = cpyStr(p->sex);
	cpyPerson->height = p->height;
	cpyPerson->year = p->year;

	return cpyPerson;
}

char* cpyStr(char* s)
{
	int len = strlen(s);
	char* n = (char*)malloc(sizeof(char) * (len + 1));
	n[len] = 0;
	n = strcpy(n, s);
	return n;
}